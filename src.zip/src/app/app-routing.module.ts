import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddComponent } from './add/add.component';
import { EditComponent } from './edit/edit.component';
import { ForgetComponent } from './forget/forget.component';
import { HomepageComponent } from './homepage/homepage.component';
import { LoginComponent } from './login/login.component';
import { RegistrationComponent } from './registration/registration.component';
import { ViewByIdComponent } from './view-by-id/view-by-id.component';
import { ViewComponent } from './view/view.component';
const routes: Routes = [
  {path:"login", component:LoginComponent},
  {path:"registration", component:RegistrationComponent },
  {path:'',component:LoginComponent},
  {path:'forget',component:ForgetComponent},
  {path:'homepage',component:HomepageComponent},
  {path:'view',component:ViewComponent},
  {path:'add',component:AddComponent},
  {path:'viewById',component:ViewByIdComponent},
  {path:'edit',component:EditComponent},
  {path:'edit/:id',component:EditComponent},

]
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
