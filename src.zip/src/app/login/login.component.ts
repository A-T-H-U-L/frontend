import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute,Router } from '@angular/router';
import { AuthServiceService } from '../service/auth-service.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
loginForm!: FormGroup;
loginError:boolean = false;
  constructor(private _router:Router,private _myservice:AuthServiceService,private _activatedRouter:ActivatedRoute) { 
this.loginForm = new FormGroup({
  email: new FormControl(null, Validators.required),
  password:new FormControl(null, Validators.required)
})

  }

  ngOnInit(): void {
  }


  isValid(controlName:any){
    return this.loginForm.get(controlName)?.invalid && this.loginForm.get(controlName)?.touched;
  }
  
  login(){
    if(this.loginForm.valid){
console.log(this.loginForm.value);
this._myservice.login(this.loginForm.value)
.subscribe(
  (data)=>{
   
    console.log(data)
    console.log(this.responseMsg(data))
    this.tokenGenerate(data)
    localStorage.setItem
    this._router.navigate(['/','view'])
  },
  
);
    }
    console.log('aaaa')
 
  }


tokenGenerate(token:any){
  localStorage.setItem("token",token.token)
}
responseMsg(data:any){
  console.log(data.data)
}

  
// moveToRegister(){
//   this._router.navigate(['../login'],{relativeTo:this._activatedRouter})
// }

}
