import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthServiceService } from '../service/auth-service.service';


@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {
myForm!:FormGroup;
UniqueId:any;
succesMessage=''
  constructor(private _myservice:AuthServiceService ,private _arouter:ActivatedRoute,private _router:Router) { }

  ngOnInit(): void {
   
    console.log("asas")
    this.UniqueId=this._arouter.snapshot.params['id'];
    console.log( this._arouter.snapshot.params['id'])
    this._myservice.getDataById(this._arouter.snapshot.params['id']).subscribe(
      (result)=>{console.log(result)
      
        this.myForm=new FormGroup({
          name:new FormControl(result[0].fullname),
          locality:new FormControl(result[0].locality),
          experience:new FormControl(result[0].experience),
          speciality:new FormControl(result[0].speciality)
       
    
    
        });
        console.log(this.myForm.value)
      
      }
    )

  

  }
// edit(){
 
//   this._myservice.edit( this._view.pid).subscribe(
//     (data)=>{this.succesMessage='Resgistration success'
//     console.log(data)
//   }
  
//   );
// }
update(){
  console.log('AA')
   
  console.log('AA')
console.log(this.myForm.value)

this._myservice.update(this.myForm.value,this.UniqueId)
.subscribe(
data=>this.succesMessage='Updationsuccess'

);
console.log('AA')
console.log('AA')
this.myForm.reset();
this._router.navigate(['/','view'])





}



}
