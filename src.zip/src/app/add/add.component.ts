import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthServiceService } from '../service/auth-service.service';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {
  myForm!:FormGroup;

  succesMessage="";
  constructor(private _router:Router,private _myservice:AuthServiceService,private _activatedRouter:ActivatedRoute) {
    this.myForm=new FormGroup({
      name:new FormControl(null,Validators.required),
      locality:new FormControl(null,Validators.email),
      experience:new FormControl(null,Validators.required),
      speciality:new FormControl(null,Validators.required)
   
      

    });

   }

  ngOnInit(): void {
  }



  add(){
    console.log('AA')
   
      console.log('AA')
    console.log(this.myForm.value)
this._myservice.addDetails(this.myForm.value)
.subscribe(
  data=>this.succesMessage='Resgistration success'

);
console.log('AA')
this.myForm.reset();
this._router.navigate(['/','view'])

   


  }


}
