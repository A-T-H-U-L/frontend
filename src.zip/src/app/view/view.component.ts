import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthServiceService } from '../service/auth-service.service';

@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.css']
})
export class ViewComponent implements OnInit {
   allDetails:any=[];
   pid:any
   succesMessage=''
  constructor(private _router:Router,private _myservice:AuthServiceService,private _activatedRouter:ActivatedRoute) { }

  ngOnInit() {
    this._myservice.viewall().subscribe(res=>{
      console.log(res)
    this.allDetails=res;
    console.log("s"+this.allDetails)
  })
  }





  logOut(){
    localStorage.removeItem('token');
    this._router.navigate(['/','login'])

  }


  navigateToAdd(){


    this._router.navigate(['/','add'])
  }
  navigateToEdit(id:any){
   // this._router.navigate(['/','edit'])
console.log("id"+id)
this.pid=id
  }

  delete(id:any){
    this._myservice.delete(id).subscribe(
      data=>this.succesMessage='Deleted'
      
      )
      console.log(this.succesMessage)
     
      
this._router.navigate(['/','view'])
console.log("aa")
  }

}
