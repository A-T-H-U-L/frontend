import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { EditComponent } from '../edit/edit.component';

@Injectable({
  providedIn: 'root'
})
export class AuthServiceService {

  constructor(private _http:HttpClient) { }


  submitRegistration(body:any){
    return this._http.post('http://localhost:3000/registration',body,{
      observe:'body'
    })
  }





login(body:any){
  return this._http.post('http://localhost:3000/login',body,{
    observe:'body'
  })
}

addDetails(body:any){
  return this._http.post('http://localhost:3000/addDetails',body,{
    observe:'body'
  })



}






viewall(){
  return this._http.get<any>('http://localhost:3000/getdetails')
    
}




edit(body:any){
  return this._http.post('http://localhost:3000/edit',body,{
    observe:'body'
  })



}


getDataById(id:any){
  return this._http.get<any>(`http://localhost:3000/getdetail/${id}`)
}





update(body:any,id:any){
  return this._http.put(`http://localhost:3000/update/${id}`,body,{
    observe:'body'
  })

}
viewById(id:any){
  return this._http.get<any>(`http://localhost:3000/viewById/${id}`)

}


delete(id:any){

  return this._http.delete<any>(`http://localhost:3000/delete/${id}`)

}

}
