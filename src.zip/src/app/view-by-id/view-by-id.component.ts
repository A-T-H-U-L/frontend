import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-by-id',
  templateUrl: './view-by-id.component.html',
  styleUrls: ['./view-by-id.component.css']
})
export class ViewByIdComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
