import { Component, OnInit } from '@angular/core';
import { AbstractControl,FormControl, FormGroup, NgForm, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthServiceService } from '../service/auth-service.service';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
   myForm!:FormGroup;
   succesMessage='';

  

  constructor(private _router:Router,private _myservice:AuthServiceService,private _activatedRouter:ActivatedRoute) {
    

    this.myForm=new FormGroup({
      name:new FormControl(null,Validators.required),
      email:new FormControl(null,Validators.email),
     password:new FormControl(null,Validators.required),
      confirmPassword: new FormControl(null,this.passwordValidator)
      

    });
  

   }

  ngOnInit(): void {
  }
  isValid(controlName:any){
    return this.myForm.get(controlName)?.invalid && this.myForm.get(controlName)?.touched;
  }
  onSubmit(form:NgForm){
    console.log("form is submited"+" "+form)
    console.log(form.value)
    console.log(form)
  }

  passwordValidator(control:AbstractControl){
    if(control && (control.value !==null || control.value == undefined)){
const cnfpassValue=control.value;
const passControl=control.get('password');
if(passControl){
  const pswdValue=passControl.value;
  if(pswdValue !==cnfpassValue || pswdValue ===''){
    return{
      isError:true
    };
  }
}
    }
    return null;
  }

  registration(){
    if(this.myForm.valid){
    console.log(this.myForm.value)
this._myservice.submitRegistration(this.myForm.value)
.subscribe(
  (data)=>{
   
    if(data == 'sucess') {
      this.succesMessage='Resgistration success'
    }else{
      
    }
  }
);

this.myForm.reset();
this._router.navigate(['/','login'])
    }


  }



moveToLogin(){
  this._router.navigate(['../login'],{relativeTo:this._activatedRouter})
}





}
